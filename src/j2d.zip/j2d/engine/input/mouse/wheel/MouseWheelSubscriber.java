package j2d.engine.input.mouse.wheel;

public interface MouseWheelSubscriber {
    void mouseWheelMoved(int direction, int amount);
}
