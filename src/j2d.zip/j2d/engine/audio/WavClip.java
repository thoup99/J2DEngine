package j2d.engine.audio;

public class WavClip extends AudioClip {

    @Override
    public void loadResource(String rscPath) {

    }

    @Override
    public void loadAbsolute(String absPath) {

    }

    @Override
    public void play() {

    }

    @Override
    public void play(float start) {

    }

    @Override
    public float pause() {
        return 0;
    }

    @Override
    public void stop() {

    }
}
