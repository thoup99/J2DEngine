package j2d.components.physics.collider;

import j2d.engine.gameobject.GameObject;

public class BoxCollider extends Collider {

    public BoxCollider(GameObject parentGameObject) {
        super(parentGameObject);
    }
}
